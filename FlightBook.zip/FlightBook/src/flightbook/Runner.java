package flightbook;
/**
 * Runs the Tester 
 */
public class Runner
{    
    public static void main(String[] args)
    {
       new Tester().doTest();
    }
}
